<?php
session_start();

    include 'pembeli/logout.php';
    $_SESSION = array();

// Hancurkan sesi
session_destroy();

// Redirect ke halaman tertentu (misalnya, index.php)
header("Location: ../index.php");
exit();
?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ... (sisa kode logout.php)



