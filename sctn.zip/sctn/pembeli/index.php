<?php

  include 'koneksi.php';


  $data_produk = array();
  $ambil = $koneksi->query("SELECT * FROM produk ");

  while($pecah = $ambil->fetch_assoc()){

    $data_produk[]= $pecah;
  }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pembeli</title>
        <link rel="stylesheet" href="mana.css">
    </head>
    <body>
    
    <header>
        <nav>
            <div class="sayap">
                <div class="logo">
                    <a href=""><img src="gambar/gagap.png.png.png" class="putih"/></a>
                    <a class="putih">Makanan Khas Papua</a>
            </button>
        </div>

     <div class="menu">
        <ul>
            <li><a href="#menu">Menu</a></li>
            <li><a href="#contact">Contact</a></li>

            <!-- Nav Item - Logout -->
              <li class="nav-item">
              <a class="nav-link" href="index.php?logout">
              <i class="fas fa-sign-out-alt"></i>
              <span>Logout</span>
            </a>
          </li>

    </nav>

    <main>
    <section id="menu" class="menu-toh">
    <h1 class="section-title">Menu Spesial Makanan Khas Papua</h1>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const beliButtons = document.querySelectorAll('.menu__button');

    beliButtons.forEach(button => {
      button.addEventListener('click', function () {
        const itemId = button.getAttribute('data-id');
        // Menggunakan window.location.href untuk mengarahkan ke login.php dengan mengirimkan parameter item
        window.location.href = 'belanja.php?item=' + itemId;
      });
    });
  });
</script>

      <?php foreach($data_produk as $key => $values): ?>
        <div class="menu__container bd-grid">
          <div class="menu__content">
            <div class="menu-item">
              <img src="gambar/<?php echo $values['gambar'] ?>" alt="" class="menu__img" />
              <h3 class="menu__name"><?php echo $values['nama'] ?></h3>
              <span class="menu__detail">Detail</span>
              <p class="menu__detail"><?php echo $values['deskripsi'] ?></p>
              <span class="menu__preci">Rp.<?php echo $values['harga'] ?></span>
              <a href="#" class="button menu__button" data-id="belanja.php">Beli</a>
            </div>
          </div>

          <?php endforeach ?>

    <section id="contact">
      <footer class="footer-container">
        <div class="footer-menu">
            <section>
                <div class="logo-container">
                    <a href="#">
                        <img src="gambar/gagap.png.png.png">
                    </a>
                </div>
                  <h2>Makanan Khas Papua</h2>
            </section>

            <section>
              <h3>Community</h3>
              <ul>
                  <li><a href="#">Activity</a></li>
                  <li><a href="#">Members</a></li>
                  <li><a href="#">Groups</a></li>
                  <li><a href="#">Forums</a></li>
              </ul>
          </section>
          
          <section>
              <h3>Hubungi Kami</h3>
              <ul>
                <li><a href="mailto:makaspa05@gmail.com"><i class="fas fa-envelope fa-fw"></i> makaspa05@gmail.com</a></li>
                <li><a href="https://wa.me/6282198424487" target="_blank"><i class="fab fa-whatsapp fa-fw"></i> 082198424487</a></li>
                <li><a href="https://www.google.com/maps/place/Rumah+Makan+Sari+Nanana/@-0.8804214,131.2627602,17z/data=!4m6!3m5!1s0x2d59552d21e1a307:0x52cb703a753552a3!8m2!3d-0.8804268!4d131.2653351!16s%2Fg%2F11c6cppkrs?entry=ttu" target="_blank"><i class="fas fa-map-marker-alt fa-fw"></i>Pusat Belanja Makaspa</a></li>
                </ul>
          </section>
          
          <section>
            <h3>Jam Operasional Kerja</h3>
            <ul>
                <li><a> Hari Senin - Sabtu</a></li>
                <li><a> Jam 09.00 - 22.00 WIT</a></li>
                <li><a> Hari Minggu Libur</a></li>
                <li><a> Tanggal Merah Libur</a></li>
            </ul>
        </section>

        <div class="footer-copyright">
            <div>
                <small>&copy; Sorong City Technologi Networking 2024</small>
            </div>
    </footer>

        </section>
  </main>
</body>
</html>

