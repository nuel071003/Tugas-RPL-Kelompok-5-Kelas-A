<h1 class="h3 mb-4 text-gray-800"> Edit Data Produk</h1>

<?php

    $id_produk = $_GET['id_produk'];

    $ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk ='$id_produk'");
    $pecah = $ambil->fetch_assoc();
?>

<form action="" method="post" enctype="multipart/form-data">
    <div class="card shadow">
    <div class="card-body">
            <div class="form-grup row">
                <label for="" class="col-sm-3 col-form-label">ID produk</label>
                <div class="col-sm-9">
                    <input type="number" name="id_produk" class="form-control" value="<?php echo $pecah['id_produk']; ?>">
                </div>
            </div>
        </div>

    <div class="card shadow">
        <div class="card-body">
            <div class="form-grup row">
                <label for="" class="col-sm-3 col-form-label">Nama</label>
                <div class="col-sm-9">
                    <input type="text" name="nama_produk" class="form-control" value="<?php echo $pecah['nama']; ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="" class="col-sm-3 col-form-label">Harga</label>
                <div class="col-sm-9">
                    <input type="number" name="harga_produk" class="form-control" value="<?php echo $pecah['harga']; ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="" class="col-sm-3 col-form-label">Deskripsi</label>
                <div class="col-sm-9">
                    <input type="text" name="deskripsi_produk" class="form-control" value="<?php echo $pecah['deskripsi']; ?>">
                </div>
            </div>


            <div class="card-body">
                <div class="form-grup row">
                <label for="" class="col-sm-3 col-form-label">Foto Produk</label>
                <div class="col-sm-9">
                    <img src="../gambar/" alt="" class="img-renponsive" width="150">
                    <input type="file" name="gambar_produk" class="form-control"  value="<?php echo $pecah['gambar']; ?>">>

        <div class="card-footer py-3">
            <div class="row">
                <div class="col">
                    <a href="index.php?produk" class="btn btn-sm btn-danger">
                        <i class="fas fa-chevron-left"></i> Kembali
                    </a>
                </div>

                <div class="col text-right">
                    <button name="simpan" class="btn btn-sm btn-primary">
                        Simpan <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<?php 
    if (isset($_POST['simpan'])){
        // Tangkap data dari form
        $nama_produk = $_POST['nama_produk'];
        $harga_produk = $_POST['harga_produk'];
        $deskripsi_produk = $_POST['deskripsi_produk'];

        // Periksa apakah file gambar diunggah
        if(isset($_FILES['gambar_produk']['name']) && $_FILES['gambar_produk']['name'] != ''){
            $gambar_produk = $_FILES['gambar_produk']['name'];
            $tmp_name = $_FILES['gambar_produk']['tmp_name'];
            $path = "../gambar/";
            move_uploaded_file($tmp_name, $path . $gambar_produk);
        } else {
            // Jika tidak ada gambar baru yang dipilih, gunakan gambar yang sudah ada
            $gambar_produk = $pecah['gambar'];
        }

        // Update data dalam tabel produk
        $update_produk_query = "UPDATE produk 
                                SET 
                                nama = '$nama_produk',
                                harga = '$harga_produk',
                                deskripsi = '$deskripsi_produk',
                                gambar = '$gambar_produk'
                                WHERE id_produk = '$id_produk'";
        
        $update_produk_result = $koneksi->query($update_produk_query);

        // Periksa apakah pembaruan produk berhasil
        if ($update_produk_result) {
            echo "<script>alert('Data Produk Berhasil Diedit');</script>";
            echo "<script>location='index.php?produk';</script>";
        } else {
            echo '<div class="alert alert-danger mt-3" role="alert">Error: ' . $koneksi->error . '</div>';
        }
    }
?>

