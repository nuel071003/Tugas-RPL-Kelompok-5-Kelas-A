<?php
// Hapus semua variabel sesi
session_unset();

// Hancurkan sesi
session_destroy();

// Redirect ke halaman login atau beranda setelah logout
header("Location: ../index.php");
exit();
?>
