<?php
include 'koneksi.php';

$id_produk = $_GET['id_produk'];


$koneksi->query("DELETE FROM produk WHERE id_produk = $id_produk ");

    echo "<script>alert('Data  Produk Berhasil Dihapus');</script>";
    echo "<script>location='index.php?produk';</script>";

?>