

<h1 class="h3 mb-4 text-gray-800"> Tambah Data  Produk</h1>

<form action="" method="post" enctype="multipart/form-data">
    <div class="card shadow">
        <div class="card-body">
            <div class="form-grup row">
                <label for="" class="col-sm-3 col-form-label">Nama produk</label>
                <div class="col-sm-9">
                    <input type="text" name="nama_produk" class="form-control" placeholder="Nama produk">
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="form-grup row">
                <label for="" class="col-sm-3 col-form-label">Harga produk</label>
                <div class="col-sm-9">
                    <input type="number" name="harga_produk" class="form-control" placeholder="Harga produk">
                </div>
            </div>
        </div>


        <div class="card-body">
            <div class="form-grup row">
                <label for="" class="col-sm-3 col-form-label">Deskrisi produk</label>
                <div class="col-sm-9">
                    <textarea  name="deskripsi_produk" class="form-control" placeholder="Deskripsi produk"></textarea>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="form-grup row">
                <label for="" class="col-sm-3 col-form-label">Foto Produk</label>
                <div class="col-sm-9">
                    <div class="input-foto">
                    <input type="file" name="foto_produk" class="form-control">
                   </div>
                </div>
            </div>
        </div>

        <div class="card-footer py-3">
            <div class="row">
                <div class="col">
                    <a href="index.php?produk" class="btn btn-sm btn-danger">
                        <i class="fas fa-chevron-left"></i> Kembali
                    </a>
                </div>

                <div class="col text-right">
                    <button name="simpan" class="btn btn-sm btn-primary">
                        Simpan <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<?php 
    if(isset($_POST['simpan'])){
       
        $nama = $_POST['nama_produk'];
        $harga = $_POST['harga_produk'];
        $deskripsi = $_POST['deskripsi_produk'];

        $nama_foto = $_FILES['foto_produk']['name'];
        $lokasi_foto = $_FILES['foto_produk']['tmp_name'];

        move_uploaded_file($lokasi_foto,"../gambar/".$nama_foto);

        //memasukan data kedalam tabel produk

        $koneksi->query("INSERT INTO produk (nama,deskripsi,harga,gambar)
        VALUES ('$nama','$deskripsi','$harga','$nama_foto')");
   
    echo "<script>alert('Data  Produk Berhasil Ditambahkan');</script>";
    echo "<script>location='index.php?produk';</script>";
}
    
?>
