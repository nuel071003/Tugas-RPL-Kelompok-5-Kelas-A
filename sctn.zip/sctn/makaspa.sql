-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2024 at 02:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `makaspa`
--

-- --------------------------------------------------------

--
-- Table structure for table `belanja`
--

CREATE TABLE `belanja` (
  `id_belanja` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal_pembelian` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembeli`
--

CREATE TABLE `pembeli` (
  `id_pembeli` int(11) NOT NULL,
  `nama_pembeli` varchar(255) NOT NULL,
  `no_hp` int(30) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembeli`
--

INSERT INTO `pembeli` (`id_pembeli`, `nama_pembeli`, `no_hp`, `alamat`, `username`, `password`) VALUES
(1, 'Clif Igobula', 2147483647, 'km 17', 'clif@gmail.com', '$2y$10$LyyCSUNuttKwct47hqlsEOIpwdZStQfmdUbW9zLBNJdkyUwrYbGk.'),
(2, 'nuel', 2147483647, 'km 17', 'nuel', '$2y$10$BT7THdhxMbf7HPO8xbI6I.WQB9iGZgHqLB.pD2J1sE8syr0ibcfpK'),
(3, 'nuel', 2147483647, 'kpr polisi', 'saya', '$2y$10$slm/nzwEMem7FG9nyvwgEuVq16Y7q/cuGRhY2OH4rQQsVRQRDIKEK'),
(4, 'nuel', 2147483647, 'km 17', 'imanuel', '$2y$10$lnxNbGxYijBmQQp0vDPp1u.LJQE8GtTbUvdkL4SJPObgQn2cbrHb2');

-- --------------------------------------------------------

--
-- Table structure for table `penjual`
--

CREATE TABLE `penjual` (
  `id` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penjual`
--

INSERT INTO `penjual` (`id`, `id_produk`, `username`, `password`) VALUES
(17, 0, 'makaspa05@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `id_penjual` int(11) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `harga` int(11) NOT NULL,
  `deskripsi` varchar(500) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `id_penjual`, `nama`, `harga`, `deskripsi`, `gambar`) VALUES
(8, 0, 'papeda', 25000, 'Makanan ini mengandung Vitamin A  sebanyak 0 IU, Vitamin B1 sebanyak 0,01 mg, Vitamin C sebanyak 0 mg</p>\r\nMakanan ini mengandung energi, protein , karbohidrat, lemak, kalsium, fosfor, dan zat besi', 'papeda.jpg'),
(9, 0, 'Ikan Kuah Kuning', 30000, 'Makanan ini mengandung Vitamin A  sebanyak 0 IU, Vitamin B1 sebanyak 0 mg., Vitamin C sebanyak 0 mg.\r\nMakanan ini mengandung energi, protein, karbohidrat, dan lemak', 'ikan_kuah_kuning.jpg'),
(10, 0, 'Ikan Bungkus', 25000, 'Makanan ini mengandung Vitamin A  sebanyak 0 IU, Vitamin B1 sebanyak 0 mg., Vitamin C sebanyak 0 mg.\r\nMakanan ini mengandung energi, protein, karbohidrat, dan lemak', 'ikanbngks.jpg'),
(11, 0, 'Sagu Lempeng', 25000, 'Makanan ini mengandung Vitamin B1 sebesar 0,30 mg.\r\nMakanan ini mengandung Karbohidrat total, energi, protein dan lemak.', 'sagu_lempeng.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `belanja`
--
ALTER TABLE `belanja`
  ADD PRIMARY KEY (`id_produk`),
  ADD KEY `id_belanja` (`id_belanja`);

--
-- Indexes for table `pembeli`
--
ALTER TABLE `pembeli`
  ADD PRIMARY KEY (`id_pembeli`);

--
-- Indexes for table `penjual`
--
ALTER TABLE `penjual`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `belanja`
--
ALTER TABLE `belanja`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembeli`
--
ALTER TABLE `pembeli`
  MODIFY `id_pembeli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `penjual`
--
ALTER TABLE `penjual`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `belanja`
--
ALTER TABLE `belanja`
  ADD CONSTRAINT `belanja_ibfk_1` FOREIGN KEY (`id_belanja`) REFERENCES `produk` (`id_produk`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
