<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Hash the password before storing it in the database
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Simpan data ke dalam tabel pembeli
    $insert_query = "INSERT INTO pembeli (id, username, password) VALUES ('id', '$username', '$hashed_password')";
    $insert_result = mysqli_query($conn, $insert_query);

    if ($insert_result) {
        echo "Pendaftaran berhasil. Silakan login <a href='halaman_pembeli.html'>di sini</a>.";
    } else {
        echo "Terjadi kesalahan dalam query database pendaftaran.";
    }
}
?>
